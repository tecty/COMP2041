#!/bin/bash
cat $1 | cut -d: -f5
