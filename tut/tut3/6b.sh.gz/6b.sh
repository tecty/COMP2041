#!/bin/bash

 cat $1 | egrep "^(cs|se|bi|en)"
